<h1>Resultado del problema</h1>

Entrada

[![Imagen 15](https://i.postimg.cc/7YtkbMLW/Screenshot-3.png)](https://postimg.cc/MvB4FBV7)

Salida

[![Imagen 15](https://i.postimg.cc/2SqfWbb8/Screenshot-4.png)](https://postimg.cc/G41NwpxZ)
