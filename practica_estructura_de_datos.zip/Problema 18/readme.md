<h1>Resultado del problema</h1>

Entrada

[![Imagen 18](https://i.postimg.cc/hPNpvf9B/Screenshot-9.png)](https://postimg.cc/8jBhnkKK)

Salida

[![Imagen 18.1](https://i.postimg.cc/cLYTn0m8/Screenshot-10.png)](https://postimg.cc/G4Lk006c)
