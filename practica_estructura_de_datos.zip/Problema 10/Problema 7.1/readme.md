<h1>Salida del problema</h1>

[![Imagen 7.5](https://i.postimg.cc/kMw1JhHW/Screenshot-6.png)](https://postimg.cc/7bGMXXwL)

[![Imagen 7.6](https://i.postimg.cc/7YGgFsrH/Screenshot-7.png)](https://postimg.cc/xcQJHPdh)

[![Imagen 7.7](https://i.postimg.cc/Rq5N5Twh/Screenshot-8.png)](https://postimg.cc/m1jb7CXW)

[![Imagen 7.8](https://i.postimg.cc/50zXPGFT/Screenshot-9.png)](https://postimg.cc/HcpWn6z9)

[![Imagen 7.9](https://i.postimg.cc/g0FFVTmn/Screenshot-10.png)](https://postimg.cc/k2cp9wVm)
