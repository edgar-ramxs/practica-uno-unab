class Node:
    def __init__(self, coordinates, demand, name, draft):
        self.name = name
        self.coordinates = coordinates
        self.demand = demand
        self.draft = draft
