<h1>Salida del problema</h1>


[![Imagen 4](https://i.postimg.cc/qvJXjCb4/Screenshot-4.png)](https://postimg.cc/tYcxg7GM)
[![Imagen 4.1](https://i.postimg.cc/ZKhLvQ69/Screenshot-4-1.png)](https://postimg.cc/4nBcrBLZ)
[![Imagen 4.2](https://i.postimg.cc/bNH9xRRm/Screenshot-4-2.png)](https://postimg.cc/pprjxz4j)
