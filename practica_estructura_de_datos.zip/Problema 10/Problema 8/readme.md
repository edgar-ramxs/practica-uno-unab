<h1>Salida del problema</h1>

[![Imagen 8](https://i.postimg.cc/8PwfX3zn/Screenshot-1.png)](https://postimg.cc/dLk0L5d8)
