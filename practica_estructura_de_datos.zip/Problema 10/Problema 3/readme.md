<h1>Salida del problema</h1>

[![Imagen 3](https://i.postimg.cc/28jHyJQz/Screenshot-3.png)](https://postimg.cc/0r3GHVX3)
