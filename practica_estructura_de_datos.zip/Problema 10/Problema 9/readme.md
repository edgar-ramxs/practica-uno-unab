<h1>Salida del problema</h1>

[![Imagen 9](https://i.postimg.cc/gkb1tSTR/Screenshot-2.png)](https://postimg.cc/QVS6Hbsx)
