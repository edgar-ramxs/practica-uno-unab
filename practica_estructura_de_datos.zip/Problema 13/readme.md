<h1>Resultado del problema</h1>

Entrada

[![Imagen 13](https://i.postimg.cc/ZRtsC03g/Screenshot-8.png)](https://postimg.cc/gwsH7zgq)

Salida

[![Imagen 13.1](https://i.postimg.cc/26Qcvm75/Screenshot-9.png)](https://postimg.cc/qh7xVPYf)
