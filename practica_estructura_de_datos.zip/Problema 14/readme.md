<h1>Resultado del problema</h1>

Entrada

[![Imagen 14](https://i.postimg.cc/rzXwH1tj/Screenshot-1.png)](https://postimg.cc/GTKR8sKT)

Salida

[![Imagen 14.1](https://i.postimg.cc/bYG0KqtS/Screenshot-2.png)](https://postimg.cc/G9CsDwzb)
