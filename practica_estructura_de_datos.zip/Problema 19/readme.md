<h1>Resultado del problema</h1>

Entrada

[![Imagen 19](https://i.postimg.cc/905GdNBF/Screenshot-3.png)](https://postimg.cc/YGRGkRVJ)

Salida

[![Imagen 19.1](https://i.postimg.cc/7h3SmMB1/Screenshot-4.png)](https://postimg.cc/p5d9d8My)
