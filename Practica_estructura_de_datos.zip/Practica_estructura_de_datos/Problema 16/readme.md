<h1>Resultado del problema</h1>

Entrada

[![imagen 16](https://i.postimg.cc/NMGt5NRZ/Screenshot-5.png)](https://postimg.cc/d7fpfjH9)

Salida

[![Imagen 16.1](https://i.postimg.cc/26HDv4wy/Screenshot-6.png)](https://postimg.cc/tZVwGn8G)
