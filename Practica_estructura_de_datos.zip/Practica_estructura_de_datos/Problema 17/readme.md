<h1>Resultado del problema</h1>

Entrada

[![Imagen 17](https://i.postimg.cc/pXQphSjL/Screenshot-7.png)](https://postimg.cc/F7R9wDGM)

Salida

[![Imagen 17.1](https://i.postimg.cc/6p9TdhVL/Screenshot-8.png)](https://postimg.cc/rKP8TxPK)
