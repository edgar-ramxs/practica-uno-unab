<h1>Resultado del problema</h1>

Entrada del problema

[![Imagen 12](https://i.postimg.cc/Kjd2zmG8/Screenshot-7.png)](https://postimg.cc/0Kd3XRKT)

Salida del problema

[![Imagen 12.1](https://i.postimg.cc/ZRsmGrX3/Screenshot-6.png)](https://postimg.cc/7Gzj7THY)
