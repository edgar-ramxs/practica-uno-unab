<h1>Salida del problema</h1>

[![Imagen 10](https://i.postimg.cc/tJnZ1Cj1/Screenshot-3.png)](https://postimg.cc/fSZTpskZ)

[![Imagen 10.1](https://i.postimg.cc/7bvCS8HK/Screenshot-4.png)](https://postimg.cc/SYrNpPz9)
