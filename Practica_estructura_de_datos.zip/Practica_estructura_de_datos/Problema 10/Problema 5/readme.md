<h1>Salida del problema</h1>

Ejemplo:

Para este problema, tienes múltiples opciones. Agregamos 4 trabajadores y revisamos sus posiciones.

[![Imagen 5](https://i.postimg.cc/ZR7P6XpN/Screenshot-1.png)](https://postimg.cc/qhKCTbmB)

[![Imagen 5.1](https://i.postimg.cc/wM1X2FQG/Screenshot-2.png)](https://postimg.cc/dZKZt2X2)

Luego agregamos 5 trabajadores y revisamos cómo fueron reordenados.

[![Imagen 5.2](https://i.postimg.cc/Vv2jVM7L/Screenshot-3.png)](https://postimg.cc/30C4yy5P)
