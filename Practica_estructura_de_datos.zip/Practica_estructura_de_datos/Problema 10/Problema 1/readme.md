<h1>Salida del problema</h1>

[![Imagen 1](https://i.postimg.cc/65R4hWP3/Screenshot-1.png)](https://postimg.cc/SJSKShkF)
