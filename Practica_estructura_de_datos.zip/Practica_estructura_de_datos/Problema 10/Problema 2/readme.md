<h1>Salida del problema</h1>

[![Image 2](https://i.postimg.cc/gJCWmpXk/Screenshot-2.png)](https://postimg.cc/ftfFf6f6)
