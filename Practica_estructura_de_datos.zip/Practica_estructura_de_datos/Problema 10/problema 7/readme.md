<h1>Salida del problema</h1>

Archivo A.txt

[![Imagen 7](https://i.postimg.cc/vHvwrzDz/Screenshot-11.png)](https://postimg.cc/rKzHc510)

Archivo B.txt

[![Imagen 7.1](https://i.postimg.cc/4yWRp61y/Screenshot-12.png)](https://postimg.cc/RJJYBnyx)

Archivo C.txt

[![Imagen 7.2](https://i.postimg.cc/8k47ZxKJ/Screenshot-13.png)](https://postimg.cc/Z09YRsh4)

Archivo D.txt

[![Imagen 7.3](https://i.postimg.cc/Y2Y5kHK0/Screenshot-14.png)](https://postimg.cc/BtZYcRvf)

Archivo E.txt

[![Imagen 7.4](https://i.postimg.cc/pdMjwzDp/Screenshot-15.png)](https://postimg.cc/gx4rRwtW)
