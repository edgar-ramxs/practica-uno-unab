<h1>Salida del problema</h1>

[![Imagen 6](https://i.postimg.cc/8578dQxQ/Screenshot-4.png)](https://postimg.cc/8JgnD31t)

[![Imagen 6.1](https://i.postimg.cc/VLpJXmT1/Screenshot-5.png)](https://postimg.cc/D8QfTknY)
