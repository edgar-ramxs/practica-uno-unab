<h1>Resultado del problema</h1>

Entrada

[![Imagen 20](https://i.postimg.cc/ydFJH6Fs/Screenshot-5.png)](https://postimg.cc/phLVQHG6)

Salida

[![Imagen 20.1](https://i.postimg.cc/L52J6dTf/Screenshot-6.png)](https://postimg.cc/N9CspzZf)
