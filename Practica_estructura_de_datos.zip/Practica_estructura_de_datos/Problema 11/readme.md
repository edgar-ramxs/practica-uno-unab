<h1>Salida del problema</h1>

[![Imagen 11](https://i.postimg.cc/QCzzbmw4/Screenshot-5.png)](https://postimg.cc/N21bG6gm)
